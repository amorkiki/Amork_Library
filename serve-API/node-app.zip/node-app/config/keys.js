module.exports = {
  mongoURI: "mongodb+srv://amork:jing985464@cluster0.jiogy.mongodb.net/test",
  secretOrKey: "secret",
};
